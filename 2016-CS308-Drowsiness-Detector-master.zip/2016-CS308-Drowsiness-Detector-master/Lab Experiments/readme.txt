Group A 
Prateek Chandan (120050042)
Deependra Patel (120050032)

Group B
Adit Kabra (120050034)
Manohar Kumar (120050044)


We have added the codes for all the lab assignments
