# Project Name: Drowsiness Detector

##Team Members:

1. Prateek Chandan (120050042)
2. Adit Kabra (120050034)
3. Deependra Patel (120050032)
4. Manohar Kumar (120050044)

##Project Description:

Sleep deprivation affects driving as much as (and sometimes more than) alcohol. It has been estimated that approximately 20% of vehicle accidents have sleep deprivation as a cause.
Noticing the trend and studying the factors of the person sleeping few common things could be noticed like the pulse rate of the person drops , the person starts blinking eye quickly and with longer durations , there could be difference in the driving way etc. We have exploited the first two important factor. We have used sensors to determine the heart rate and eye blink duration. Using those readings we will determine if the person is sleeping or not and based upon that we will raise an alarm

This project , “drowsiness detection system” will detect that and can be installed in the cars to prevent drowsiness based accidents


