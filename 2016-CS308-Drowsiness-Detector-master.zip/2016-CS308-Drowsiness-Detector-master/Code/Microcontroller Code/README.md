# Drowsiness-Detection-Embedded-System

The main code resides in lab-0.c